
## Julia Nelson 
"""
k-means Segmentation
	Apply k-means segmentation on white-tower.png with k=10. 
	The distance function should only consider the RGB color channels and ignore pixel coordinates. 
	Randomly pick 10 RGB triplets from the existing pixels as initial seeds and run to convergence.  
	After k-means has converged, represent each cluster with the average RGB value of its members.



SLIC
Apply a variant of the SLIC algorithm to wt_slic.png, by implementing the following steps: 
	1. Divide the image in blocks of 50×50 pixels and initialize a centroid at the center of each block. 
	2. Compute the magnitude of the gradient in each of the RGB channels and use the square root 
	    of the sum of squares of the three magnitudes as the combined gradient magnitude. Move the centroids 
	    to the position with the smallest gradient magnitude in 3×3 windows centered on the initial centroids. 
	3. Apply k-means in the 5D space of x, y, R, G, B. Use the Euclidean distance in this space, 
	    but divide x and y by 2. 
	4. After convergence, display the output image: color pixels that touch two different clusters black 
	    and the remaining pixels by the average RGB value of their cluster. 


CAN USE 
image reading and writing functions
plotting functions
 can convert the images to a different format for reading them.


CANNOT USE 
filtering 
edge detection 
any other image processing functions. 

the complexity of k-means is linear with respect to the number of pixels and k. 
Start developing on small images with small values of k.
"""

import cv2
import math 
import numpy as np
